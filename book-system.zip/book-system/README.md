1 Unzip the file and store into the local xampp or wamp.
run npm start
2 C:\xampp\htdocs\book-system>npm install
3 C:\xampp\htdocs\book-system>npm start 
4 if you get error please use npm install to install to new version
4 http://localhost:3000/
